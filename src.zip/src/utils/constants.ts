export const Roles = {
  ADMINISTRADORES: "ADMINISTRADORES",
  OTRO: "OTRO"
};
