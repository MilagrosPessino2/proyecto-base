const AdminPage = () => {
  return <h1>Hola, esta es la página del ADMINISTRADOR</h1>;
};

export default AdminPage;