import React, { useRef, useState, useEffect } from 'react'
import { DefaultButton, PrimaryButton } from '@fluentui/react/lib/Button'
import styles from './AdjuntarArchivos.module.scss'

interface Archivo {
    id: string
    nombre: string
    esImagen: boolean
    url?: string
    fp: string
}

const AdjuntarArchivos: React.FC = () => {
    const [archivos, setArchivos] = useState<Archivo[]>([])
    const ref = useRef<HTMLInputElement>(null)
    const seq = useRef(0)

    useEffect(() => {
        return () => {
            archivos.forEach((a) => a.url && URL.revokeObjectURL(a.url))
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    const handleUpload = () => ref.current?.click()

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const files = Array.from(e.target.files ?? [])
        const nuevos: Archivo[] = []

        const existentes = new Set(archivos.map((a) => a.fp))
        const agregadosAhora = new Set<string>()
        const duplicados: string[] = []

        for (const f of files) {
            const fp = `${f.name}|${f.size}|${f.lastModified}`
            if (existentes.has(fp) || agregadosAhora.has(fp)) {
                duplicados.push(f.name)
                continue
            }

            const esImagen =
                /image\/(jpeg|png)/i.test(f.type) ||
                /\.(jpe?g|png)$/i.test(f.name)
            const id = `${Date.now()}-${seq.current++}`

            if (esImagen) {
                const url = URL.createObjectURL(f)
                nuevos.push({ id, nombre: f.name, esImagen: true, url, fp })
            } else {
                nuevos.push({ id, nombre: f.name, esImagen: false, fp })
            }
            agregadosAhora.add(fp)
        }

        if (duplicados.length)
            alert(
                `Se ignoraron archivos duplicados: ${Array.from(
                    new Set(duplicados)
                ).join(', ')}`
            )
        if (nuevos.length) setArchivos((prev) => [...prev, ...nuevos])
        e.target.value = ''
    }

    const handleRemove = (id: string) => {
        setArchivos((prev) => {
            const file = prev.find((a) => a.id === id)
            if (file?.url) URL.revokeObjectURL(file.url)
            return prev.filter((a) => a.id !== id)
        })
    }

    const handleClear = () => {
        archivos.forEach((a) => a.url && URL.revokeObjectURL(a.url))
        setArchivos([])
    }

    return (
        <div className={styles.home}>
            <input
                ref={ref}
                type='file'
                multiple
                onChange={handleChange}
                style={{ display: 'none' }}
            />

            <div className={styles.toolbar}>
                <PrimaryButton
                    text='Adjuntar archivos'
                    onClick={handleUpload}
                />
                <DefaultButton
                    text='Limpiar'
                    onClick={handleClear}
                    disabled={!archivos.length}
                />
            </div>

            <div className={styles.gallery}>
                {archivos.map((file) => (
                    <div className={styles.imgCard} key={file.id}>
                        <div className={styles.imgCardInner}>
                            {file.esImagen && file.url ? (
                                <img
                                    className={styles.cardImg}
                                    src={file.url}
                                    alt={file.nombre}
                                />
                            ) : (
                                <span
                                    className={styles.fileName}
                                    title={file.nombre}
                                >
                                    {file.nombre}
                                </span>
                            )}
                        </div>

                        {/* botón va después para quedar arriba */}
                        <button
                            type='button'
                            className={styles.removeBtn}
                            aria-label={`Eliminar ${file.nombre}`}
                            title='Eliminar'
                            onClick={() => handleRemove(file.id)}
                        >
                            ×
                        </button>
                    </div>
                ))}
            </div>
        </div>
    )
}

export default AdjuntarArchivos
