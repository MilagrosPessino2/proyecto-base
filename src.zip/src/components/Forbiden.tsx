const Forbidden = () => {
  return (
    <div style={{ padding: "2rem", textAlign: "center" }}>
      <h1>403 - Acceso denegado</h1>
      <p>No tenés permisos para acceder a esta página.</p>
    </div>
  );
};

export default Forbidden;
